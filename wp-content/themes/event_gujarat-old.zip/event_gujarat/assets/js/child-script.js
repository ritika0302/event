/**
 * Wrapper function to safely use $
 */
function gujChildWrapper($) {

    /*global generalPar:false, ajaxPar:false, gform:false, wp, GUJModals */
    var gujChild = {

        /**
         * Main entry point
         */
        init: function () {
            gujChild.registerEventHandlers();
            gujChild.datePicker();
            gujChild.eventValidate();
        },

        /**
         * Registers event handlers
         */
        registerEventHandlers: function () {
            $(document).on('click','#resetFilter',gujChild.resetForm);
            $(document).on('submit','#eventFrm',gujChild.eventAdd);
        },

         /**
         * Date handlers
         */
        datePicker: function () {
            var selected_date = $("#datepicker").val();
            if (selected_date == '') {
                $('#datepicker1').prop('disabled', true);
            }
            $("#datepicker").datepicker({
                minDate: 0,
                onSelect: function (date) {
                    selected_date = $(this).val();
                      if (selected_date != '') {
                        $('#datepicker1').prop('disabled', false);
                      }
                    var date2 = $('#datepicker').datepicker('getDate');
                    date2.setDate(date2.getDate());
                    $('#datepicker1').datepicker('setDate', date2);
                    //sets minDate to dt1 date + 1
                    $('#datepicker1').datepicker('option', 'minDate', date2);
                }
            });

            $('#datepicker1').datepicker({
            });
        },

        // Reset Map form
        resetForm: function (e) {
            e.preventDefault();
            $('#filter-store').trigger("reset");
            location.reload();
        }, 

        // Validate Add Event Form
        eventValidate: function (e) {
            jQuery("#eventFrm").validate({
                ignore: "",
                rules: {
                    eventname: {
                      required: true,
                      minlength : 2,
                      maxlength: 30,
                    },
                    organiser : {
                        required: true,
                    },
                    eventlocation : {
                        required: true,
                        minlength : 2,
                        maxlength: 100,
                    },
                    startdate : {
                        required: true,
                    },
                    enddate : {
                        required: true,
                    }         
                },
                messages: {
                    eventname: "Please enter event name",
                    organiser: "Please select organiser",
                    eventlocation: "Please enter event location",
                    startdate: "Please select start date",
                    enddate: "Please select end date",
                },
                onkeyup: false
            });
        },       

        // Add event form using frontend callback
        eventAdd: function (e) {
            e.preventDefault();
            if(!$("#eventFrm").valid()) 
            {return false;}

            // $('.loader').show();
            // jQuery("#event_btn").prop('disabled', true);
            var passData = $("#eventFrm").serialize();
            passData = passData+'&action=add_event&nonce='+ajaxPar.gujNonce;
            if (passData) {
                $.ajax({
                    url: ajaxPar.ajaxUrl,
                    type: 'post',
                    data: passData,
                    success: function (response) {
                        response = JSON.parse(response);
                        // if (response.status === 'success') {
                        //     jQuery('.all-location-store').html( response.html );
                        //     //initMap();
                        // } else {
                        //     jQuery('.all-location-store').html( response.html );
                        // }
                    }
                });
            }   
        },           

    }; // end gujChild

    $(document).ready(gujChild.init);

} // end gujChildWrapper()

gujChildWrapper(jQuery);
