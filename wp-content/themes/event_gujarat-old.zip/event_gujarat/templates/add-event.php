<?php  
/* 
Template Name: Add Event Template 
*/    
get_header();?>  
   
<div class="page-main">
  <div class="container">
      <div class="event_inner">
        <h2>Add Event</h2>
        <form id="eventFrm">
          <div class="form-group">
            <label for="eventName">Event Name</label>
            <input type="text" class="form-control" name="eventname" id="eventName" placeholder="Enter event name">
          </div>
          <div class="form-group">
            <label for="eventOrganiser">Event Organiser</label>
            <div class="org-label">
                <?php 
                $events = get_terms( array(
                    'taxonomy' => 'events_organisers',
                    'hide_empty' => false
                ) );
                 
                if ( !empty($events) ) :
                    
                    foreach( $events as $event ) {
                        $output.= '<label><input type="checkbox" name="'. esc_html( $event->name ) .'" value="'. esc_attr( $event->term_id ) .'"> '. esc_html( $event->name ) .'</label>';
                    }
                    echo $output;
                endif;
              ?>
            </div>            
          </div>
          <div class="form-group">
            <label for="eventLocation">Event Location</label>
            <input type="text" class="form-control" name="eventlocation" id="eventLocation" placeholder="Enter location">
          </div>
          <div class="form-group">
            <label for="datepicker">Event Start Date</label>
            <input type="text" class="form-control" name="startdate" id="datepicker" placeholder="Select Start Date" readonly='true'>
          </div>
          <div class="form-group">
            <label for="datepicker1">Event End Date</label>
            <input type="text" class="form-control" name="enddate" id="datepicker1" placeholder="Select End Date" readonly='true'>
          </div>          
          <button type="submit" class="btn btn-primary" id="event_btn">Submit</button>
        </form>
      </div>
  </div>  
</div>
<?php get_footer(); ?>
